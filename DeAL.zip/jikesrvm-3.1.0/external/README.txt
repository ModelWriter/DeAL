This directory tree contains additional (non Java class library) code 
that is imported and modified from other external open source projects. 
Because each component is available under it's own license we 
must make those modifications available under their original license.

By convention, each sub-tree with source contains a copy of the
license under which code in that tree is distributed. Care must be
taken when adding/editing code in this portion of the Jikes RVM tree
to be aware of the license(s) under which the code is provided.  Any
contributions from non-core team members to this portion of the tree
must have appropriate license statements in the patch tracker before
the change may be committed.
